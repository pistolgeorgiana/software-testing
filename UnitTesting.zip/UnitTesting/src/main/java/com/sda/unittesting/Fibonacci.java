package com.sda.unittesting;

public class Fibonacci {
//    public static int getValue(int element) {
//        return 0;
//    }

//    public static int getValue(int element) {
//        if (element == 0) {
//            return 0;
//        }
//
//        if (element == 1) {
//            return 1;
//        }
//
//        int result = 0;
//        int position1 = 0;
//        int position2 = 1;
//
//        // f(0) = 0
//        // f(1) = 1
//        // f(2) = f(0) + f(1) = 0 + 1 = 1
//        // f(3) = f(1) + f(2) = 1 + 1 = 2
//
//        if (element > 1) {
//            for (int i = 2; i <= element; i++) {
//                result = position1 + position2;
//                position2 = position1;
//                position1 = result;
//            }
//        }
//
//        return result;
//    }

    public static int getValue(int element) {
        if (element == 0 || element == 1) {
            return element;
        }

        return getValue(element - 2) + getValue(element - 1);
    }
}