package com.sda.unittesting;

public class Calculator {

    public int add(int i, int i1) {
        return i + i1;
    }
}
