package com.sda.unittesting.exercises;

public class Calculator {
    public double add(double first, double second) {
        return first + second;
    }

    public double subtraction(double first, double second) {
        return first - second;
    }

    public double multiply(double first, double second) {
        return first * second;
    }

    public double divide(double first, double second) {
        if (second == 0) {
            throw new IllegalArgumentException("Dividend cannot be 0");
        }
        return first / second;
    }

    //1. Create Calculator class and implement operations: addition, subtraction,
    //multiplication, division. Then create CalculatorTest class with tests above
    //operations.

    //2. Change Calculator class from task one to use the AssertJ assertion
}
