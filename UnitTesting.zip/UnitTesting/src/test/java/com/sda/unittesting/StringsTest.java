package com.sda.unittesting;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class StringsTest {

    @ParameterizedTest
    @CsvSource({"  test  ,TEST", "tEst ,TEST", "   Java,JAVA"})
    void shouldTrimAndUppercaseInput(String input, String expected) {
        String actualValue = Strings.toUpperCase(input);
        assertEquals(expected, actualValue);
    }

    @ParameterizedTest
    @CsvSource(value = {"  test  ;TEST", "tEst ;TEST", "   Java;JAVA"}, delimiter = ';')
    void shouldTrimAndUppercaseInputWithDelimiter(String input, String expected) {
        String actualValue = Strings.toUpperCase(input);
        assertEquals(expected, actualValue);
    }

    @ParameterizedTest
    @CsvFileSource(resources = "/data.csv", numLinesToSkip = 1) // the data.csv file must be in the classpath root, we skip the first line in the file
    void shouldUppercaseAndBeEqualToExpected(String input, String expected) {
        String actualValue = Strings.toUpperCase(input);
        assertEquals(expected, actualValue);
    }

    @ParameterizedTest
    @NullSource
    void shouldbeBlankForNull(String input) {
        assertTrue(Strings.isBlank(input));
    }

    @ParameterizedTest
    @EmptySource
    void shouldNotBeValid(List<String> input) {
        assertTrue(input.isEmpty());
    }

    @ParameterizedTest
    @NullAndEmptySource
    void nullAndEmptyShouldBeBlank(String input) {
        assertTrue(Strings.isBlank(input));
    }

}