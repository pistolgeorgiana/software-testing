package com.sda.unittesting.exercises;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {

    Calculator calculator = new Calculator();

    @Test
    @DisplayName("When dividend is 0 throw exception")
    void testDivideWhenDividendIsZeroThenThrowError() {
        final IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> calculator.divide(1, 0));

        assertThat(exception).hasMessage("Dividend cannot be 0")
                .hasNoCause();

        assertThatThrownBy(() -> calculator.divide(10, 0))
                .isExactlyInstanceOf(IllegalArgumentException.class)
                .hasMessage("Dividend cannot be 0")
                .hasNoCause();

        assertThatIllegalArgumentException()
                .isThrownBy(() -> calculator.divide(10, 0))
                .withMessage("Dividend cannot be 0")
                .withNoCause();

        assertThatExceptionOfType(IllegalArgumentException.class)
                .isThrownBy(() -> calculator.divide(10, 0))
                .withMessage("Dividend cannot be 0")
                .withNoCause();
    }


    @ParameterizedTest
    @MethodSource("provideNumbersAdd")
    void shouldAddTwoNumbers(double first, double second, double result) {
        assertEquals(result, calculator.add(first, second));
    }

    @ParameterizedTest
    @MethodSource("provideNumbersSubtraction")
    void shouldSubtractionTwoNumbers(double first, double second, double result) {
        assertEquals(result, calculator.subtraction(first, second));
    }

    @ParameterizedTest
    @MethodSource("provideNumbersMultiply")
    void shouldMultiplyTwoNumbers(double first, double second, double result) {
        assertEquals(result, calculator.multiply(first, second));
    }

    @ParameterizedTest
    @MethodSource("provideNumbersDivide")
    void shouldDivideTwoNumbers(double first, double second, double result) {
        assertEquals(result, calculator.divide(first, second));
    }

    private static Stream<Arguments> provideNumbersAdd() {
        return Stream.of(Arguments.of(1, 2, 3),
                Arguments.of(3, 4, 7),
                Arguments.of(5, 6, 11));
    }

    private static Stream<Arguments> provideNumbersSubtraction() {
        return Stream.of(Arguments.of(110, 20, 90),
                Arguments.of(15, 5, 10),
                Arguments.of(15, 6, 9));
    }

    private static Stream<Arguments> provideNumbersMultiply() {
        return Stream.of(Arguments.of(1, 2, 2),
                Arguments.of(3, 4, 12),
                Arguments.of(5, 6, 30));
    }

    private static Stream<Arguments> provideNumbersDivide() {
        return Stream.of(Arguments.of(12, 4, 3),
                Arguments.of(30, 6, 5),
                Arguments.of(5, 1, 5));
    }
}