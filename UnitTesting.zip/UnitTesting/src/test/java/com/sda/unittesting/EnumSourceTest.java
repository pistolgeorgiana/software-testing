package com.sda.unittesting;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class EnumSourceTest {

    @ParameterizedTest
    @EnumSource(TemperatureConverter.class)
    void shouldConvertToValueHigherThanMinInteger(TemperatureConverter converter) {
        assertTrue(converter.convertTemp(10) > Integer.MIN_VALUE);
    }

    @ParameterizedTest
    @EnumSource(value = TemperatureConverter.class, names = {"CELSIUS_KELVIN", "CELSIUS_FAHRENHEIT"})
    void shouldConvertToTemperatureLowerThanMaxInteger(TemperatureConverter converter) {
        assertTrue(converter.convertTemp(10) < Integer.MAX_VALUE);
    }

    @ParameterizedTest
    @EnumSource(value = TemperatureConverter.class,
            names = {"KELVIN_CELSIUS"},
            mode = EnumSource.Mode.EXCLUDE)
    void shouldConvertTemperatureToPositiveValue(TemperatureConverter converter) {
        assertTrue(converter.convertTemp(10) > 0); // the test will run for the values CELSIUS KELVIN and CELSIUS FAHRENHEIT
    }
}
