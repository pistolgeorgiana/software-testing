package com.sda.unittesting;

import org.junit.jupiter.api.*;

import static org.assertj.core.api.Assertions.assertThat;

public class ExampleTest {

    @BeforeAll
    static void setUp() {
        System.out.println("This message will be displayed  once before execution of all testing methods");
    }

    @AfterAll
    static void tearDown() {
        System.out.println("This message will be displayed  once after  execution of all testing methods");
    }

    @BeforeEach
    void init() {
        System.out.println("This message will be displayed before execution of each testing method");
    }

    @AfterEach
    void initAfter() {
        System.out.println("This message will be displayed after execution of each testing method");
    }

    @Test
    @DisplayName("First testing method")
    void firstTest() {
        System.out.println("Executing first test...");
    }

    @Test
    @Disabled
    void secondTest() {
        System.out.println("Executing second test...");
    }

    @Test
    @DisplayName("Given When Then")
    void testAdd() {
        // Given
        Calculator calculator = new Calculator();

        // When
        int result = calculator.add(2, 3);

        // Then
        Assertions.assertEquals(5, result);
//        Assertions.assertEquals(5, result, "Testing using assertEquals");
    }

    @Test
    public void testNotNull() {
        String text = "SDA Academy";
        Assertions.assertNotNull(text);
        Assertions.assertNotNull(text, "Testing using assertNotNull");
    }

    @Test
    public void testNull() {
        String text = null;
        Assertions.assertNotNull(text);
        Assertions.assertNotNull(text, "Testing using assertNull");
    }

    @Test
    public void testTrue() {
        boolean value = true;
        Assertions.assertTrue(value);
        Assertions.assertTrue(value, "Testing using assertTrue");
    }

    @Test
    public void testFalse() {
        boolean value = false;
        Assertions.assertFalse(value);
        Assertions.assertFalse(value, "Testing using assertFalse");
    }

    @Test
    public void testArrayEquals() {
        Assertions.assertArrayEquals(new int[]{1,2,3}, new int[]{1,2,3});
        Assertions.assertArrayEquals(new int[]{1,2,3}, new int[]{1,2,3}, "Testing using assertArrayEquals");
    }

    @Test
    void shouldAddTwoNumbersAssertJ() {
        int result = 1 + 3;
        assertThat(result).isEqualTo(4);
    }

    @Test
    void shouldAddTwoNumbersAssertJChain() {
        int result = 1 + 3;

        assertThat(result)
                .isEqualTo(4)
                .isNotEqualTo(5)
                .isLessThan(6)
                .isGreaterThan(3)
                .isBetween(0, 10);
    }
}
