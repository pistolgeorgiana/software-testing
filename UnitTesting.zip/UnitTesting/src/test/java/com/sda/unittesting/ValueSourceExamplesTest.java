package com.sda.unittesting;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;

public class ValueSourceExamplesTest {

    @ParameterizedTest
    @ValueSource(doubles = {1, 2.3, 4.1})
    void shouldPassDoubleToParam(double param) {
        assertThat(param).isGreaterThan(0);
    }

    @ParameterizedTest
    @ValueSource(strings = {"Ala", "has a", "cat"})
    void shouldPassStringToTest(String word) {
        assertThat(word.length()).isGreaterThan(2);
    }

    @ParameterizedTest
    @ValueSource(classes = {String.class, Integer.class, Double.class})
    void shouldPassClassTypeAsParam(Class<?> clazz) {
    }
}
